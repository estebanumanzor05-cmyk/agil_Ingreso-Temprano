"""
Genera una imagen de código de barra (Code 128) por cada producto del mock data.

Uso:
    pip install python-barcode pillow
    python generar_codigos_barra.py

Lee los SKU (7891011121314, 7891011121301, ...) desde la sección INSERT INTO
productos de mock_data_sprint1.sql y guarda una imagen PNG por producto en la
carpeta codigos_barra/. El código de barra contiene solo el SKU.

IMPORTANTE: si cambias los SKU en el SQL, borra la carpeta codigos_barra/
antes de volver a ejecutar, para que no queden imágenes viejas.
"""
import re
from pathlib import Path

import barcode
from barcode.writer import ImageWriter

ARCHIVO_SQL = Path("mock_data_sprint1.sql")
CARPETA_SALIDA = Path("codigos_barra")


def leer_skus(ruta_sql):
    """Extrae los SKU de la sentencia INSERT INTO productos, en orden."""
    texto = ruta_sql.read_text(encoding="utf-8")
    bloque = re.search(r"INSERT INTO productos.*?;", texto, re.S | re.I)
    if not bloque:
        raise SystemExit("No se encontró 'INSERT INTO productos' en el archivo SQL.")
    # El SKU es el primer texto entre comillas de cada fila: ('SKU', 'nombre', ...)
    skus = re.findall(r"\(\s*'([^']+)'", bloque.group(0))
    return list(dict.fromkeys(skus))  # quita repetidos conservando el orden


def main():
    CARPETA_SALIDA.mkdir(exist_ok=True)
    skus = leer_skus(ARCHIVO_SQL)

    # Code 128 admite letras, números y guion (EAN-13 solo admite números)
    code128 = barcode.get_barcode_class("code128")

    for sku in skus:
        imagen = code128(sku, writer=ImageWriter())
        ruta = imagen.save(str(CARPETA_SALIDA / sku))  # crea 7891011121314.png
        print(f"Generado: {ruta}")

    print(f"\nListo: {len(skus)} códigos de barra en '{CARPETA_SALIDA}/'")


if __name__ == "__main__":
    main()