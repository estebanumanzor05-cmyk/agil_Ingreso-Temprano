-- =====================================================================
-- MOCK DATA - SPRINT 1 (T03: Insertar productos de prueba)
-- Proyecto: Sistema de consulta de productos mediante código de barra
-- Historias cubiertas: HU04 (registrar productos), HU01 (consultar
-- producto por código) y HU02 (ver tallas y cantidades)
-- 13 productos de prueba, datos ficticios.
--
-- Adaptado al prototipo de la interfaz: el SKU del Zapato Oxford Clásico
-- (7891011121314), sus tallas/cantidades y su ubicación (Pasillo 4, Fila B)
-- son los mismos que muestra la pantalla de resultados.
--
-- El SKU es lo único que lleva el código de barra y es la llave primaria.
-- Se guarda como TEXTO (VARCHAR), no como número: debe coincidir exactamente
-- con el código impreso y viaja como texto en el JSON de la API.
--
-- NOTA: las tablas de abajo son una propuesta. Ajustar nombres y
-- campos a lo que se defina en T01 / T02 (modelo y creación de BD).
-- =====================================================================

-- ---------- Tablas (propuesta) ----------
CREATE TABLE productos (
    sku     VARCHAR(20)  PRIMARY KEY,
    nombre  VARCHAR(100) NOT NULL,
    marca   VARCHAR(50)  NOT NULL
);

CREATE TABLE tallas_inventario (
    sku      VARCHAR(20) NOT NULL REFERENCES productos(sku),
    talla    INT         NOT NULL,
    cantidad INT         NOT NULL DEFAULT 0,
    PRIMARY KEY (sku, talla)
);

-- Ubicación como la muestra la pantalla: "Pasillo 4, Fila B"
CREATE TABLE ubicaciones (
    sku     VARCHAR(20) PRIMARY KEY REFERENCES productos(sku),
    pasillo INT         NOT NULL,
    fila    CHAR(1)     NOT NULL
);

-- ---------- Productos ----------
INSERT INTO productos (sku, nombre, marca) VALUES
('7891011121314', 'Zapato Oxford Clásico', 'Flexi'),
('7891011121301', 'Tenis Runner Pro', 'Nike'),
('7891011121302', 'Mocasín Clásico', 'Hush Puppies'),
('7891011121303', 'Sandalia Verano', 'Adidas'),
('7891011121304', 'Tenis Court Classic', 'Puma'),
('7891011121305', 'Bota Trabajo Industrial', 'Timberland'),
('7891011121306', 'Tenis Old Skool', 'Vans'),
('7891011121307', 'Chuck Taylor High', 'Converse'),
('7891011121308', 'Sandalia Clog', 'Crocs'),
('7891011121309', 'Zapatilla Walk Comfort', 'Skechers'),
('7891011121310', 'Tenis Edición Limitada', 'Puma'),
('7891011121311', 'Zapato Escolar Negro', 'Flexi'),
('7891011121312', 'Tenis Training Flex', 'Reebok');

-- ---------- Tallas y cantidades ----------
-- Cubre los 4 colores de la pantalla: 0 (rojo), 1-2 (naranja), 3-4 (amarillo), 5+ (verde).
-- Incluye tallas agotadas y un producto con una sola talla.
INSERT INTO tallas_inventario (sku, talla, cantidad) VALUES
('7891011121314', 39, 2), ('7891011121314', 40, 0), ('7891011121314', 41, 5), ('7891011121314', 42, 1), ('7891011121314', 43, 3),
('7891011121301', 38, 4), ('7891011121301', 39, 2), ('7891011121301', 40, 0), ('7891011121301', 41, 6), ('7891011121301', 42, 3),
('7891011121302', 40, 3), ('7891011121302', 41, 1), ('7891011121302', 42, 2),
('7891011121303', 36, 5), ('7891011121303', 37, 5), ('7891011121303', 38, 2),
('7891011121304', 36, 3), ('7891011121304', 37, 6), ('7891011121304', 38, 5), ('7891011121304', 39, 2),
('7891011121305', 40, 2), ('7891011121305', 41, 3), ('7891011121305', 42, 3), ('7891011121305', 43, 2), ('7891011121305', 44, 1),
('7891011121306', 37, 1), ('7891011121306', 38, 4), ('7891011121306', 39, 4), ('7891011121306', 40, 2),
('7891011121307', 36, 2), ('7891011121307', 38, 3), ('7891011121307', 40, 5), ('7891011121307', 42, 0),
('7891011121308', 38, 8), ('7891011121308', 40, 6), ('7891011121308', 42, 4),
('7891011121309', 36, 2), ('7891011121309', 37, 3), ('7891011121309', 38, 3), ('7891011121309', 39, 0),
('7891011121310', 41, 1),
('7891011121311', 34, 6), ('7891011121311', 35, 6), ('7891011121311', 36, 5), ('7891011121311', 37, 4), ('7891011121311', 38, 2),
('7891011121312', 41, 4), ('7891011121312', 42, 5), ('7891011121312', 43, 3);

-- ---------- Ubicaciones (pasillo, fila) ----------
INSERT INTO ubicaciones (sku, pasillo, fila) VALUES
('7891011121314', 4, 'B'),
('7891011121301', 2, 'A'),
('7891011121302', 1, 'C'),
('7891011121303', 5, 'A'),
('7891011121304', 2, 'B'),
('7891011121305', 6, 'D'),
('7891011121306', 3, 'B'),
('7891011121307', 3, 'C'),
('7891011121308', 5, 'B'),
('7891011121309', 3, 'A'),
('7891011121310', 1, 'A'),
('7891011121311', 6, 'A'),
('7891011121312', 4, 'D');

-- ---------- Consulta de verificación (HU01 + HU02) ----------
-- SELECT p.sku, p.nombre, p.marca, t.talla, t.cantidad
-- FROM productos p
-- JOIN tallas_inventario t ON t.sku = p.sku
-- WHERE p.sku = '7891011121314';generar_codigos_barra.py